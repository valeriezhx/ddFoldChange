## -----------------------------------------------------------------------------
library(ddFoldChange)

## -----------------------------------------------------------------------------
head(ct_test) # check as the internal file

## -----------------------------------------------------------------------------

# run the R-code using the csv version of the dataset, replicate is 3. The output file will be print out directly. Columns 7 & 8 are delta Ct values, columns 9 & 10 are delta delta Ct values and columns 11 & 12 are gene fold changes relative to the control group. The file was saved as CSV file named "processed_data.csv".

# process_data("inst/extdata/ct_test.csv",3)

file.path <- system.file("extdata", "ct_test.csv", package = "ddFoldChange")
process.data(file.path, 3,"ct.output") # replicate=3, output_file="ct_output"


## -----------------------------------------------------------------------------

# first read "processed_data.csv" to df_process, and then run the plot function. The bar plots will be created for each gene interested.

df.process <- read.csv("ct.output", header = TRUE, sep = ',')
plot_FC(df.process)


